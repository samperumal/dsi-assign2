save(test_accuracy_wordcount_bigger, train_accuracy_wordcount_bigger,
     test_accuracy_wordcount_smaller, train_accuracy_wordcount_smaller, table_bow,
     test_accuracy_tfidf, train_accuracy_tfidf, table_tfidf,
     test_accuracy_sentiment, train_accuracy_sentiment, table_sentiment,
     test_accuracy_topic, train_accuracy_topic, table_topic,
     #baseline_accuracies,

     file = "mnn.RData")
